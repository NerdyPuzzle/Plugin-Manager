**Forge**: Describe your biome using tags here. These tags might be used by other mods for biome compatiblity and
parameters such as spawning properties.

**Fabric**: As the biome dictionnary is a Forge feature, this parameter is used to generate the biome in The End.
In order to generate your biome in the Overworld, you simply need to check the checkbox. You can generate your biome everywhere you want, but you should follow the rule 1 biome = 1 dimension.
- VOID: Generate it in The End as a small end islands biome. (Vanilla weight: 1)
- RARE: Generate it in The End as an end highlands biome. (Vanilla weight: 1)